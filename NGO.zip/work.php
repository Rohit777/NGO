<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>WORK AREA  |Kanshiram Welfare Foundation</title>
    <script defer src="https://use.fontawesome.com/releases/v5.0.6/js/all.js"></script>
    <link href="css/home.css" rel="stylesheet">
    <link href="css/sidebar.css" rel="stylesheet">
    <link href="css/heading.css" rel="stylesheet">
    <link href="css/footer.css" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/css/bootstrap.min.css" integrity="sha384-Zug+QiDoJOrZ5t4lssLdxGhVrurbmBWopoEl+M6BdEfwnCJZtKxi1KgxUyJq13dy" crossorigin="anonymous">

</head>
<body>
    
    <header>
    <nav class="navbar navbar-light bg-light top">
        <span class="navbar-text">
            <a href="index.php"><img class="logo" src="image\KANSHIRAM Foundation Logo.png" alt="logo"></a>
        </span>
        <div class="row" >  
          <div class="col-12" align="center">
                    <a href="https://www.facebook.com/pages/Kanshiram-Welfare-Foundation/163677117162571?fref=nf" target="_blank"><i class="fab fa-facebook-square fa-2x inline"  style="color:#3B5998"></i></a> 
                    <a href="https://www.youtube.com/channel/UCFxIJLpNrHBDYiPlCzVgl4A" target="_blank"><i class="fab fa-youtube fa-2x inline" style="color:#FF0000"></i></a>
                    <a href="https://www.linkedin.com/in/kanshiram-welfare-foundation-587a71161" target = "_blank"><i class="fab fa-linkedin fa-2x inline" style="color:#0077b5"></i></a>  
                    <a href="https://twitter.com/KanshiramF" target = "_blank"><i class="fab fa-twitter-square fa-2x inline" style="color: #00aced"></i></a>            
          </div>
              <div class="col-12" align="center">
                  <a href="donation.php" style="color:#8c2a00; font-weight:700; font-size:1.3rem;"><span>Donation</span></a>
              </div>
        </div>
    </nav>
        <nav class="navbar navbar-expand-lg navbar-dark navbar-custom" style="background-color: #8c2b00ed" id="stick">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse justify-content-center navbar-collapse" id="navbarTogglerDemo01">
              <ul class="navbar-nav">
                <li class="nav-item active">
                  <a class="nav-link" href="index.php"><i class="fas fa-home fa-1x"></i><span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      ABOUT US
                  </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="about.php">ABOUT THE FOUNDATION</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="vision.php">VISION AND MISSION</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="team.php">OUR TEAM</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="partner.php">PARTNER</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">ANNUAL REPORT</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    OUR WORK
                  </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="education.php">EDUCATION</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="liveli.php">LIVELIHOOD</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="advoca.php">ADVOCACY</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="pre.php">PERSPECTIVE ON ELA</a>
                      <div class="dropdown-divider"></div>
                  <a class="dropdown-item" href="work.php">WORK AREA</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    GET INVOLVED
                  </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="career.php">CAREER</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="career.php">VOLUNTEER</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    PUBLICATIONS
                  </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="#">REPORTS</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">BOOKLETS</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">PAPERS</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">CASE STUDIES</a>
                    </div>
                </li>
                <li class="nav-item dropdown">
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    MEDIA
                  </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                      <a class="dropdown-item" href="#">NEWS</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">EVENTS</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">PHOTO GALLERY</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">VIDEO GALLERY</a>
                        <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="award.php">AWARDS AND RECOGNITIONS</a>
                    </div>
                </li>  
                <li class="nav-item">
                  <a class="nav-link" href="contact.php">CONTACT US</a>
                </li>     
              </ul>
            </div>
          </nav>   
    </header>
  <div class="container" style="margin-bottom:150px;">
   <div class="row">
    <div class="support-menu col-2.5">
      <nav class="vertical">
        <ul>
          <li> 
            <div>
              <ul>
                <li><a href="about.php">About the foundation</a></li>
                <li><a href="vision.php">Vision and Mission</a></li>
                <li><a href="team.php">our team</a></li>
                <li><a href="#">partner</a></li>
                <li><a href="#">annual report</a></li>
                <li><a href="work.php">work area</a></li>
              </ul>
            </div>
          </li>
        </ul>
      </nav>
    </div>
    <div class="content col-md-8">
      <div style="padding-bottom:30px;">
        <h3 class="head">Jahangir Puri, Delhi</h3>
            <p>Jahangir Puri is part of the 44 JJR colonies developed by DDA under the Plan
                    Scheme of JJ Resettlement during the period 1960 – 85. Located in north-west
                    Delhi, it is Ward No. 21 in the Delhi Metropolitan Area and is a large slum cluster
                    which is divided into 12 blocks. The area comprises of migrants mostly from the
                    eastern states such as West Bengal, Bihar and Uttar Pradesh. The migrants are
                    mostly Bengali Muslims. As per provisional reports of Census India, population of
                    Bhalswa Jahangir Pur in 2011 is 1,97,148; of which male and female are 1,06,388
                    and 90,760 respectively. 76.5 % are Hindus while Muslims comprise 21.5% of the
                    population. The remaining 2% comprise of other religions like Sikh, Christian, Jain,
                    Buddhist, etc. A larger section of population belongs to dalit community in the area.
                    The average literacy rate is 77.6%, where the average literacy rate of men is 84.21%
                    that of women is about 70%. There are more than 5000 households in the area and
                    most are engaged in the trade of rag-picking and daily wage earners.
                    As the population of the area mainly comprises of migrants, no uniform language is
                    spoken as they speak in their regional dialect. Since the migrants belong to the
                    states of West Bengal, Bihar and Uttar Pradesh, the language most commonly
                    spoken here are Magahi, Hindi and Bangla. All the houses in the area are pakka
                    houses which are constructed in a cramped manner leaving no space between the
                    adjoining houses and leaving narrow streets. Although the locality has a community
                    centre but it lacks community recreation centres and library. Public Distribution
                    System (PDS) is available and functions systematically in each block. While the
                    electricity here is provided by the New Delhi Power Ltd. (NDPL), the residents have
                    access to water supplied by the Delhi Jal Board (DJB). The locality also has a DJB
                    office. The residents have access to medical services at Babu Jagjivan Ram Hospital
                    apart from the various private clinics available in the locality. Moreover, every block
                    has a dispensary each.
                    The people here are not very educated and they are mostly labourers, rag-pickers or
                    vegetable/fruits hawkers. But the presence of government schools and by the help
                    and initiative of the organisations working in the locality has encouraged the parents
                    and children alike, and many children have taken up education with prospects of a
                    better future. At present, there are 3 government schools upto senior secondary
                    level, while every block has a primary level government school or Nagar Nigam
                    Prathamik Vidyalaya. For higher studies children opt for colleges in Delhi University
                    or IGNOU. This eagerness for education has helped some families and their children
                    who now are educated/ skilled enough to secure a respectable job and support their
                    families. This has also led to many youth from the community itself to take up the
                    initiative of helping the other families in the community.
                    The issues prevailing in the colony are unemployment, poverty, illiteracy, poor health
                    and sanitation, domestic violence, child labour, female foeticide, alcoholism, drug
                    abuse etc.</p>      
      </div>
      <div>       
        <h3 class="head">Jamui district, Bihar</h3>
             <p>Jamui, a district in the southern part of Bihar, is surrounded by the districts of
                    Lakhisarai, Banka and Munger and Nawada. Agriculture is the main occupation and
                    source of livelihood of the people of the district. The agricultural economy of Jamui is
                    dependent on rainfall. A district with a population of 17,60,405 according to the 2011
                    census, it constitutes of 86% of Hindu population and 12% of Muslim population. The
                    work of beedi making primarily involves the SC and Muslim OBC communities who
                    lost their traditional source of income.
                    Jamui has a glorious history Agriculture is the main occupation of the people of the
                    district and also the main source of livelihood of the people. Rainfall still controls the
                    agricultural economy of Jamui district. Jamui district presents a dismal picture of
                    industry. There is no big industry.Small scale industries privately owned in tiny sector
                    are found here. Jamui is a small sized district and ranks 28th in the state in order of
                    population. The population of males and females are 9,16,064 and 8,44,341 spread
                    over 3.3 percent area of the State. The population of the Jamui district during 2011
                    was 1,760,405. Hindus constitute 86.67 percent (1,525,746 persons) of the
                    population in the district followed by Muslims 12.36 percent (217,621 persons).
                    The proportion of the Scheduled Castes in the district of Jamui was 242,710
                    according to 2001 Census. Numerically the five most prominent SCs in the district
                    were (i) Musahar (85,140) (ii) Chamar, Mochi (71,909) (iii) Dusadh, Dhari, (44,599)
                    (iv) Dhobi (11,351) and (v) Pasi (10,177) while Musahar constituted the maximum
                    proportion of the Scheduled Castes population , the percentage being 35.1 (more
                    than one third of the total SC population). Jamui is one of the prominent
                    manufacturers of Beedi industry in Bihar.</p>
      </div>         
    </div>    
  </div>
</div>


<div class="container-fluid" style="background-color: #3c3d41;">
    <footer class="footer-bs">
    <div class="row">
        	  <div class="col-md-3 footer-brand animated fadeInLeft">
            	<h2>Kanshiram</h2>
                <p>Kanshiram Welfare Foundation is a research and action based non-profit organization established in 2008.
                    It aims to extend the opportunities for marginalized section across various social groups within the society.</p>
                <p>© 2018, Kanshiram Welfare Foundation, All rights reserved.</p>
            </div>
        	  <div class="col-md-5 footer-nav animated fadeInUp"> 
              <div class="row">
            	  <div class="col-6">
                  <ul class="pages">
                    <li><a href="education.php">education</a></li>
                    <li><a href="liveli.php">Livelihood</a></li>
                    <li><a href="advoca.php">Advocacy</a></li>
                    <li><a href="pre.php">PERSPECTIVE on ela</a></li>
                  </ul>
                </div>
                <div class="col-6 bug">
                  <ul class="list">
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="contact.php">Contacts</a></li>
                    <li><a href="team.php">Our Team</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                  </ul>
                </div>
              </div>
            </div>
        	  <div class="col-md-2 footer-social animated fadeInDown">
              <h4>Follow Us</h4>
              <ul>
                <li><a href="https://www.facebook.com/pages/Kanshiram-Welfare-Foundation/163677117162571?fref=nf" target="_blank">Facebook</a></li>
                <li><a href="https://www.youtube.com/channel/UCFxIJLpNrHBDYiPlCzVgl4A" target="_blank">You tube</a></li>
              </ul>
            </div>
            <div class="col-md-2 footer-ns animated fadeInRight">
              <div>
                <a href="https://www.facebook.com/pages/Kanshiram-Welfare-Foundation/163677117162571?fref=nf" target="_blank"><i class="fab fa-facebook-square fa-2x inline"  style="color:white"></i></a> 
                <a href="https://www.youtube.com/channel/UCFxIJLpNrHBDYiPlCzVgl4A" target="_blank"><i class="fab fa-youtube fa-2x inline" style="color:white"></i></a>      
                <a href="https://www.linkedin.com/in/kanshiram-welfare-foundation-587a71161" target = "_blank"><i class="fab fa-linkedin fa-2x inline" style="color:white"></i></a>              
                <a href="https://twitter.com/KanshiramF" target = "_blank"><i class="fab fa-twitter-square fa-2x inline" style="color: white"></i></a>
              </div>
            </div>
        </div>
    </footer>
  </div>

  <div class="footer-bottom">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
            <div class="copyright">
                Copyright © 2018, Kanshiram Welfare Foundation, All rights reserved.
            </div>
          </div>
          <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
            <div class="design">
               <a href="index.php"> Back to top</a> 
            </div>
          </div>
        </div>
      </div>
    </div>



        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.3/js/bootstrap.min.js" integrity="sha384-a5N7Y/aK3qNeh15eJKGWxsqtnX/wWdSZSKp+81YjTmS15nvnvxKHuzaWwXHDli+4" crossorigin="anonymous"></script>
    
</body>
</html>